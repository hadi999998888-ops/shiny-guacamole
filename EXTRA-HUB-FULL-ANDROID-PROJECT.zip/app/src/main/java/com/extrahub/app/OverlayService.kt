package com.extrahub.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.extrahub.app.model.OverlayElement
import com.extrahub.app.util.PresetManager

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private val attachedViews = mutableListOf<android.view.View>()
    private val channelId = "extra_hub_overlay"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("EXTRA HUB")
                .setContentText("Плавающий оверлей активен")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("EXTRA HUB")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
        startForeground(41, notification)
        if (Settings.canDrawOverlays(this)) showOverlay() else stopSelf()
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        val elements = PresetManager.load(this)

        elements.forEach { element ->
            when (element.type) {
                OverlayElement.TYPE_IMAGE, OverlayElement.TYPE_GIF -> addImageElement(element, metrics.widthPixels, metrics.heightPixels)
                else -> addTextElement(element, metrics.widthPixels, metrics.heightPixels)
            }
        }
        addChannelBadge()
    }

    private fun overlayParams(x: Int, y: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }

    private fun addTextElement(e: OverlayElement, screenW: Int, screenH: Int) {
        val view = TextView(this).apply {
            text = e.text
            textSize = (22f * e.scale).coerceIn(8f, 90f)
            setTextColor(Color.argb((e.alpha * 255).toInt().coerceIn(0, 255),
                Color.red(e.color.toInt()), Color.green(e.color.toInt()), Color.blue(e.color.toInt())))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            rotation = e.rotation
            setPadding(12, 7, 12, 7)
            background = GradientDrawable().apply {
                setColor(Color.argb(115, 10, 26, 63))
                cornerRadius = 16f
                setStroke(1, Color.argb(180, 59, 130, 246))
            }
        }
        addView(view, (e.x * screenW).toInt(), (e.y * screenH).toInt())
    }

    private fun addImageElement(e: OverlayElement, screenW: Int, screenH: Int) {
        if (e.imageUri.isBlank()) return
        val size = (screenW * e.width * e.scale).toInt().coerceIn(80, screenW)
        val view = ImageView(this).apply {
            alpha = e.alpha
            rotation = e.rotation
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        val params = overlayParams((e.x * screenW).toInt(), (e.y * screenH).toInt()).apply {
            width = size
            height = WindowManager.LayoutParams.WRAP_CONTENT
        }
        runCatching {
            windowManager.addView(view, params)
            attachedViews.add(view)
            Glide.with(applicationContext).load(Uri.parse(e.imageUri))
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(view)
        }
    }

    private fun addView(view: android.view.View, x: Int, y: Int) {
        runCatching {
            windowManager.addView(view, overlayParams(x, y))
            attachedViews.add(view)
        }
    }

    private fun addChannelBadge() {
        val badge = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 10, 8)
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 5, 9, 20))
                cornerRadius = 36f
                setStroke(2, Color.argb(230, 59, 130, 246))
            }
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        badge.addView(logo, LinearLayout.LayoutParams(72, 72))
        val channelText = TextView(this).apply {
            text = "НАШ КАНАЛ"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(9, 0, 12, 0)
            typeface = Typeface.DEFAULT_BOLD
        }
        badge.addView(channelText)
        badge.setOnClickListener {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/ExtraCheatStanddof2"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 25f
            setTextColor(Color.WHITE)
            setPadding(10, 0, 8, 0)
            setOnClickListener { stopSelf() }
        }
        badge.addView(close)
        val edit = TextView(this).apply {
            text = "⚙"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(8, 0, 8, 0)
            setOnClickListener {
                startActivity(Intent(this@OverlayService, EditorActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        badge.addView(edit)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = 12
            y = 18
        }
        runCatching {
            windowManager.addView(badge, params)
            attachedViews.add(badge)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "EXTRA HUB overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        attachedViews.forEach { view -> runCatching { windowManager.removeView(view) } }
        attachedViews.clear()
        Glide.get(applicationContext).clearMemory()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
