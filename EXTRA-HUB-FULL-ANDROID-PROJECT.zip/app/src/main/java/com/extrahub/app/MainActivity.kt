package com.extrahub.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.extrahub.app.ui.screens.HomeScreen
import com.extrahub.app.ui.theme.*
import com.extrahub.app.util.PresetManager

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            var settings by remember { mutableStateOf(false) }
            var dark by remember { mutableStateOf(PresetManager.loadTheme(this)) }
            ExtraHubTheme(dark) {
                if (!settings) HomeScreen { settings = true }
                else Column(Modifier.fillMaxSize().background(if (dark) AppBackground else MaterialTheme.colorScheme.background).padding(20.dp)) {
                    Text("Настройки", color = MaterialTheme.colorScheme.onBackground, fontSize = 24.sp)
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Тёмная тема", color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
                        Switch(checked = dark, onCheckedChange = {
                            dark = it
                            PresetManager.saveTheme(this@MainActivity, it)
                        })
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("О приложении", color = MaterialTheme.colorScheme.onBackground, style = MaterialTheme.typography.titleMedium)
                    Text("EXTRA HUB • версия 1.1", color = MaterialTheme.colorScheme.onBackground)
                    TextButton(onClick = {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/ExtraCheatStanddof2")))
                    }) { Text("Открыть Telegram-канал") }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { settings = false }) { Text("Назад") }
                }
            }
        }
    }
}
