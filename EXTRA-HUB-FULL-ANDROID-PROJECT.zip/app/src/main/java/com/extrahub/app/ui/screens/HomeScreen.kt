package com.extrahub.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.extrahub.app.EditorActivity
import com.extrahub.app.OverlayService
import com.extrahub.app.R
import com.extrahub.app.ui.theme.*
import com.extrahub.app.util.PresetManager

@Composable
fun HomeScreen(onSettings: () -> Unit) {
    val context = LocalContext.current
    var elements by remember { mutableStateOf(PresetManager.load(context)) }
    var status by remember { mutableStateOf("Оверлей готов к запуску") }

    Column(Modifier.fillMaxSize().background(AppBackground).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("EXTRA HUB", color = AppText, fontSize = 25.sp)
                Text("STREAM OVERLAY STUDIO", color = Accent, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = AppText)
            }
        }
        Spacer(Modifier.height(22.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("УПРАВЛЕНИЕ ОВЕРЛЕЕМ", color = AppText, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(5.dp))
                Text(status, color = Accent, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (!Settings.canDrawOverlays(context)) {
                            context.startActivity(Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            ))
                            status = "Разреши EXTRA HUB отображение поверх окон"
                        } else {
                            context.startForegroundService(Intent(context, OverlayService::class.java))
                            status = "Оверлей запущен"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Text("  Запустить оверлей")
                }
                OutlinedButton(
                    onClick = {
                        context.stopService(Intent(context, OverlayService::class.java))
                        status = "Оверлей остановлен"
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Stop, null)
                    Text("  Остановить оверлей")
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Мои элементы", color = AppText, fontSize = 19.sp)
                Text("${elements.size} элементов сохранено", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = {
                context.startActivity(Intent(context, EditorActivity::class.java))
            }) {
                Icon(Icons.Default.Add, null)
                Text(" Добавить")
            }
        }
        Spacer(Modifier.height(10.dp))
        if (elements.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
                Text(
                    "Здесь будут твои баннеры, надписи и GIF. Нажми «Добавить», чтобы собрать первый оверлей.",
                    color = Color.LightGray, modifier = Modifier.padding(18.dp)
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(elements.size) { i ->
                    val item = elements[i]
                    ListItem(
                        headlineContent = { Text(item.text.ifBlank { item.type.uppercase() }, color = AppText) },
                        supportingContent = { Text("Тип: ${item.type} • прозрачность ${(item.alpha * 100).toInt()}%", color = Color.LightGray) },
                        leadingContent = { Text(if (item.type == "text") "T" else "▧", color = Accent) },
                        trailingContent = {
                            IconButton(onClick = { context.startActivity(Intent(context, EditorActivity::class.java)) }) {
                                Icon(Icons.Default.Edit, null, tint = Accent)
                            }
                        },
                        colors = ListItemDefaults.colors(containerColor = SurfaceDark)
                    )
                }
            }
        }
    }
}
