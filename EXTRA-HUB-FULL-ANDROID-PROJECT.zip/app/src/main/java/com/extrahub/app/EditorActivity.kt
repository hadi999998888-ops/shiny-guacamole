package com.extrahub.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateListOf
import com.extrahub.app.model.OverlayElement
import com.extrahub.app.ui.screens.EditorScreen
import com.extrahub.app.ui.theme.ExtraHubTheme
import com.extrahub.app.util.PresetManager

class EditorActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val starting = PresetManager.load(this)
        setContent {
            val elements = remember { mutableStateListOf<OverlayElement>().apply { addAll(starting) } }
            val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                uri?.let {
                    runCatching {
                        contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        val raw = contentResolver.openInputStream(it)?.bufferedReader()?.use { reader -> reader.readText() }
                            ?: error("Не удалось прочитать файл")
                        val imported = PresetManager.decode(raw)
                        elements.clear()
                        elements.addAll(imported)
                        PresetManager.save(this, elements)
                        Toast.makeText(this, "Пресет импортирован", Toast.LENGTH_SHORT).show()
                    }.onFailure {
                        Toast.makeText(this, "Ошибка импорта JSON", Toast.LENGTH_LONG).show()
                    }
                }
            }
            ExtraHubTheme {
                EditorScreen(
                    elements = elements,
                    onSave = {
                        PresetManager.save(this, elements)
                        Toast.makeText(this, "Пресет сохранён", Toast.LENGTH_SHORT).show()
                    },
                    onExport = { json ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "application/json"
                            putExtra(Intent.EXTRA_TEXT, json)
                        }
                        startActivity(Intent.createChooser(send, "Экспорт JSON"))
                    },
                    onImport = { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) }
                )
            }
        }
    }
}
