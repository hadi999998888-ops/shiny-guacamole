package com.extrahub.app.util

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.extrahub.app.R

object FontProvider {
    val names = listOf(
        "Roboto", "Montserrat", "Oswald", "Bebas Neue", "Rubik", "Poppins",
        "Anton", "Bangers", "Press Start 2P", "Orbitron", "Russo One",
        "Exo 2", "Cinzel", "Playfair Display", "Lobster", "Pacifico",
        "Caveat", "Permanent Marker", "Teko", "Rajdhani"
    )

    fun family(name: String): FontFamily {
        val id = when (name.lowercase().replace(" ", "_")) {
            "montserrat" -> R.font.montserrat
            "oswald" -> R.font.oswald
            "bebas_neue" -> R.font.bebas_neue
            "rubik" -> R.font.rubik
            "poppins" -> R.font.poppins
            "anton" -> R.font.anton
            "bangers" -> R.font.bangers
            "press_start_2p" -> R.font.press_start_2p
            "orbitron" -> R.font.orbitron
            "russo_one" -> R.font.russo_one
            "exo_2" -> R.font.exo_2
            "cinzel" -> R.font.cinzel
            "playfair_display" -> R.font.playfair_display
            "lobster" -> R.font.lobster
            "pacifico" -> R.font.pacifico
            "caveat" -> R.font.caveat
            "permanent_marker" -> R.font.permanent_marker
            "teko" -> R.font.teko
            "rajdhani" -> R.font.rajdhani
            else -> R.font.roboto
        }
        return FontFamily(Font(id))
    }
}
