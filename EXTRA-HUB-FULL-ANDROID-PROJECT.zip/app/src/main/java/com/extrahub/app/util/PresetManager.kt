package com.extrahub.app.util

import android.content.Context
import com.extrahub.app.model.OverlayElement
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object PresetManager {
    private const val PREFS = "extra_hub_preferences"
    private const val ELEMENTS_KEY = "overlay_elements"
    private const val THEME_KEY = "dark_theme"
    private val gson = Gson()

    fun save(context: Context, elements: List<OverlayElement>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(ELEMENTS_KEY, gson.toJson(elements)).apply()
    }

    fun load(context: Context): MutableList<OverlayElement> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(ELEMENTS_KEY, null) ?: return mutableListOf()
        return decode(raw)
    }

    fun encode(elements: List<OverlayElement>): String = gson.toJson(elements)

    fun decode(raw: String): MutableList<OverlayElement> = runCatching {
        val type = object : TypeToken<MutableList<OverlayElement>>() {}.type
        gson.fromJson<MutableList<OverlayElement>>(raw, type) ?: mutableListOf()
    }.getOrDefault(mutableListOf())

    fun saveTheme(context: Context, dark: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(THEME_KEY, dark).apply()
    }

    fun loadTheme(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(THEME_KEY, true)
}
