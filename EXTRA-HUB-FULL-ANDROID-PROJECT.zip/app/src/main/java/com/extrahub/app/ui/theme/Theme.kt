package com.extrahub.app.ui.theme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Navy, secondary = Blue, tertiary = Accent,
    background = AppBackground, surface = SurfaceDark,
    onPrimary = Color.White, onBackground = AppText, onSurface = AppText
)
private val LightColors = lightColorScheme(
    primary = Blue, secondary = Accent, background = Color(0xFFF5F7FC),
    surface = Color.White, onSurface = Color(0xFF111827)
)
@Composable
fun ExtraHubTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
