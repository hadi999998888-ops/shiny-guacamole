package com.extrahub.app.ui.theme
import androidx.compose.ui.graphics.Color
val Navy = Color(0xFF0A1A3F)
val Blue = Color(0xFF1E3A8A)
val Accent = Color(0xFF3B82F6)
val AppBackground = Color(0xFF050914)
val SurfaceDark = Color(0xFF0F172A)
val AppText = Color(0xFFE2E8F0)
