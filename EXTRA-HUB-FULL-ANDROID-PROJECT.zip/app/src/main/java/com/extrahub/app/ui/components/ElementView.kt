package com.extrahub.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.extrahub.app.model.OverlayElement
import com.extrahub.app.util.FontProvider

@Composable
fun ElementView(
    element: OverlayElement,
    selected: Boolean,
    onUpdate: (OverlayElement) -> Unit,
    onSelect: () -> Unit
) {
    Box(
        Modifier
            .width((220 * element.scale).dp)
            .pointerInput(element.id) {
                detectDragGestures(onDragStart = { onSelect() }) { change, drag ->
                    change.consume()
                    onUpdate(element.copy(
                        x = (element.x + drag.x / size.width.coerceAtLeast(1)).coerceIn(0f, 0.96f),
                        y = (element.y + drag.y / size.height.coerceAtLeast(1)).coerceIn(0f, 0.96f)
                    ))
                }
            }
            .pointerInput(element.id) {
                detectTransformGestures { _, _, zoom, rotation ->
                    onSelect()
                    onUpdate(element.copy(
                        scale = (element.scale * zoom).coerceIn(0.25f, 3.5f),
                        rotation = element.rotation + rotation
                    ))
                }
            }
            .rotate(element.rotation)
            .alpha(element.alpha)
            .background(
                if (selected) Color(0x553B82F6) else Color.Transparent,
                RoundedCornerShape(8.dp)
            )
    ) {
        when (element.type) {
            OverlayElement.TYPE_IMAGE, OverlayElement.TYPE_GIF -> {
                if (element.imageUri.isNotBlank()) {
                    AsyncImage(
                        model = element.imageUri,
                        contentDescription = "Элемент изображения",
                        modifier = Modifier.width(220.dp)
                    )
                } else {
                    Text("Выбери файл", color = Color.White, modifier = Modifier.background(Color(0xFF1E3A8A)))
                }
            }
            else -> Text(
                text = element.text,
                color = Color(element.color.toULong()),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontProvider.family(element.font)
            )
        }
    }
}
