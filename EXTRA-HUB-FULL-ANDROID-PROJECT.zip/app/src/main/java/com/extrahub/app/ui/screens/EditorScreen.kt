package com.extrahub.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.extrahub.app.model.OverlayElement
import com.extrahub.app.ui.components.ElementView
import com.extrahub.app.ui.theme.*
import com.extrahub.app.util.FontProvider

@Composable
fun EditorScreen(
    elements: MutableList<OverlayElement>,
    onSave: () -> Unit,
    onExport: (String) -> Unit,
    onImport: () -> Unit
) {
    val context = LocalContext.current
    var selectedId by remember { mutableStateOf<String?>(null) }
    var newText by remember { mutableStateOf("НАШ КАНАЛ") }
    var selectedFont by remember { mutableStateOf("Roboto") }
    var showFonts by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching { context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val type = if (it.toString().lowercase().substringBefore("?").endsWith(".gif")) OverlayElement.TYPE_GIF else OverlayElement.TYPE_IMAGE
            elements.add(OverlayElement(type = type, text = if (type == OverlayElement.TYPE_GIF) "GIF" else "БАННЕР", imageUri = it.toString()))
            selectedId = elements.last().id
        }
    }
    Column(Modifier.fillMaxSize().background(AppBackground).padding(12.dp)) {
        Text("РЕДАКТОР ОВЕРЛЕЯ", color = AppText, style = MaterialTheme.typography.titleLarge)
        Text("Перемещай элемент пальцем. Двумя пальцами меняй размер и угол.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))

        Box(
            Modifier.weight(1f).fillMaxWidth()
                .background(Color(0xFF101B32), RoundedCornerShape(16.dp)).padding(8.dp)
        ) {
            elements.forEach { element ->
                ElementView(
                    element = element,
                    selected = selectedId == element.id,
                    onUpdate = { updated ->
                        val index = elements.indexOfFirst { it.id == updated.id }
                        if (index >= 0) elements[index] = updated
                    },
                    onSelect = { selectedId = element.id }
                )
            }
            Text("ПРЕДПРОСМОТР", color = Accent, modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd))
            if (elements.isEmpty()) {
                Text("Добавь текст, фото или GIF", color = Color.LightGray,
                    modifier = Modifier.align(androidx.compose.ui.Alignment.Center))
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = {
                elements.add(OverlayElement(type = OverlayElement.TYPE_TEXT, text = newText, font = selectedFont.lowercase().replace(" ", "_")))
                selectedId = elements.last().id
            }, modifier = Modifier.weight(1f)) { Text("+ Текст") }
            OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("+ Фото/GIF") }
        }
        OutlinedTextField(
            value = newText, onValueChange = { newText = it },
            label = { Text("Текст нового элемента") }, modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            TextButton(onClick = { showFonts = true }) { Text("Шрифт: $selectedFont") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                selectedId?.let { id -> elements.removeAll { it.id == id }; selectedId = null }
            }) {
                Icon(Icons.Default.Delete, null, tint = Color(0xFFFF6677))
                Text(" Удалить", color = Color(0xFFFF6677))
            }
        }

        selectedId?.let { id ->
            val item = elements.firstOrNull { it.id == id }
            item?.let {
                var alpha by remember(id) { mutableFloatStateOf(it.alpha) }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Прозрачность", color = AppText)
                    Spacer(Modifier.weight(1f))
                    Text("${(alpha * 100).toInt()}%", color = Accent)
                }
                Slider(
                    value = alpha, onValueChange = { value ->
                        alpha = value
                        val index = elements.indexOfFirst { e -> e.id == id }
                        if (index >= 0) elements[index] = elements[index].copy(alpha = value)
                    }, valueRange = 0f..1f
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onSave, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Save, null); Text(" Сохранить")
            }
            OutlinedButton(onClick = { onExport(com.google.gson.Gson().toJson(elements)) }) { Text("Экспорт JSON") }
        }
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("Импорт JSON из файла") }
    }

    if (showFonts) AlertDialog(
        onDismissRequest = { showFonts = false },
        title = { Text("Выбери шрифт") },
        text = {
            LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(FontProvider.names.size) { index ->
                    TextButton(onClick = {
                        selectedFont = FontProvider.names[index]
                        selectedId?.let { id ->
                            val i = elements.indexOfFirst { it.id == id }
                            if (i >= 0 && elements[i].type == OverlayElement.TYPE_TEXT) {
                                elements[i] = elements[i].copy(font = selectedFont.lowercase().replace(" ", "_"))
                            }
                        }
                        showFonts = false
                    }) { Text(FontProvider.names[index]) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showFonts = false }) { Text("Закрыть") } }
    )

}
