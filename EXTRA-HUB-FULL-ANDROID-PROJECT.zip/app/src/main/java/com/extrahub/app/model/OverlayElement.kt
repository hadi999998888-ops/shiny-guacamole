package com.extrahub.app.model

data class OverlayElement(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: String = TYPE_TEXT,
    val text: String = "EXTRA HUB",
    val imageUri: String = "",
    val x: Float = 0.08f,
    val y: Float = 0.12f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val alpha: Float = 1f,
    val font: String = "roboto",
    val color: Long = 0xFFE2E8F0,
    val width: Float = 0.42f
) {
    companion object {
        const val TYPE_TEXT = "text"
        const val TYPE_IMAGE = "image"
        const val TYPE_GIF = "gif"
    }
}
